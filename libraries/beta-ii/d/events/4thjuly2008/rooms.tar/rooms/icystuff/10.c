#include <std.h>
#include <id4.h>
inherit ROOM;

void create() {
::create();
set_properties( ([ "light" : 1, "night light" : 1]) );
set_smell("default", "The tunnel has a fresh and frozen smell to it.");
set_listen("default", "Echos near and far can be heard throughout the chilly tunnels.");
set_short("venturing through icy tunnels");
set_long("From on top of a boulder you can see the tunnels continuing as far as your sight goes.  The %^BOLD%^%^BLUE%^ice%^RESET%^ beneath your feet causes you to slip and slide, and you realize it probably wasn't the greatest idea to come up here.  After all, there's only one way down...");
set_items(([
"ice" : "Whether the sheets, boulders of, or icicles - ice covers this entire area.",
"snow" : "The ground is covered in a thin layer of snow..",
"walls" : "The walls have an occasional torch, burning through blue ice to see blue rock.",
({"rock", "rocks"}) : "The rocks are all frozen, and have turned a bluish color.",
]));
set_exits(([ "slip" : ROOMS "/icystuff/9.c"]));
}

void reset() {
::reset();
if (!present("ogre 2")) {
new(MOBS+"ogremonk")->move(this_object());
new(MOBS+"ogremonk")->move(this_object());
}
}

